document.addEventListener('mouseup', function() {
  const selection = window.getSelection().toString().trim();
  if (selection) {
    console.log("Texto selecionado: " + selection);
  }
});