let db;
let editor = null;
let currentNoteId = null;

function abrirBanco() {
  const request = indexedDB.open('blocoDeNotasAvancado', 1);
  request.onupgradeneeded = (event) => {
    db = event.target.result;
    if (!db.objectStoreNames.contains('notas')) {
      db.createObjectStore('notas', { keyPath: 'id', autoIncrement: true });
    }
  };
  request.onsuccess = (event) => {
    db = event.target.result;
    carregarNotas();
  };
}

function salvarNota({ id, texto, fixada = false }) {
  const transaction = db.transaction(['notas'], 'readwrite');
  const store = transaction.objectStore('notas');
  const dataAtual = new Date().toLocaleString();
  const nota = { texto, dataAtualizacao: dataAtual, fixada };
  if (id) { nota.id = id; } else { nota.dataCriacao = dataAtual; }
  store.put(nota);
  transaction.oncomplete = () => { carregarNotas(); };
}

function excluirNota(id) {
  const transaction = db.transaction(['notas'], 'readwrite');
  const store = transaction.objectStore('notas');
  store.delete(id);
  transaction.oncomplete = () => { carregarNotas(); };
  editor.innerHTML = '';
  currentNoteId = null;
}

function carregarNotas() {
  const transaction = db.transaction(['notas'], 'readonly');
  const store = transaction.objectStore('notas');
  const request = store.getAll();

  request.onsuccess = () => {
    let notas = request.result;
    renderizarListaNotas(notas);
  };
}

function renderizarListaNotas(notas) {
  const lista = document.getElementById('listaNotas');
  lista.innerHTML = '';
  notas.forEach((nota) => {
    const li = document.createElement('li');
    li.textContent = nota.texto.substring(0, 30) + '...';
    li.addEventListener('click', () => { carregarNotaParaEdicao(nota); });
    lista.appendChild(li);
  });
}

function carregarNotaParaEdicao(nota) {
  currentNoteId = nota.id;
  editor.innerHTML = nota.texto;
}

document.addEventListener('DOMContentLoaded', () => {
  editor = document.getElementById('editor');
  abrirBanco();
});